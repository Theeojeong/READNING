OUTPUT_DIR = "gen_musics"
GEN_DURATION = 3
TOTAL_DURATION = 10
FINAL_MIX_NAME = "final_mix.wav"